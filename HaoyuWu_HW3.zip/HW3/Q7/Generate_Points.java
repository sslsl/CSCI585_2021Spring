import java.util.*;

public class generatePoints {
    public static void main(String[] args) {
        double R = 8, r = 1, a = 4;
        double x0 = R+r-a;
        double y0 = 0;
        double nRev = 16;
        for(double t = 0; t<=Math.PI*nRev; t+=0.01){
            double x = (R+r)*Math.cos((r/R)*t) - a*Math.cos((1+r/R)*t);
            double y = (R+r)*Math.sin((r/R)*t) - a*Math.sin((1+r/R)*t);
            double x1 = -118.285419 + x/1000;
            double y1 = 34.02065 + y/1000;
            System.out.println(x1+","+y1);
        }
    }
}