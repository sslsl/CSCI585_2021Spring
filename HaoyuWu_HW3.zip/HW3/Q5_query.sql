CREATE EXTENSION postgis;

CREATE TABLE TrojanMap(id serial NOT NULL,name character varying(100),long numeric,	lat numeric);

/* Insert the 13 locations with lat, long values */
INSERT INTO TrojanMap(name, long, lat) VALUES ('1 Viterbi School of Engineering',-118.28926141247756, 34.02081408624823 );
INSERT INTO TrojanMap(name, long, lat) VALUES ('2 Annenberg School for Communication and Journalism', -118.28613936512656, 34.022261792229614);
INSERT INTO TrojanMap(name, long, lat) VALUES ('3 Leavey Library', -118.28282238916711, 34.02189642709235);
INSERT INTO TrojanMap(name, long, lat) VALUES ('4 Tommy Trojan', -118.2854509538234, 34.020749310758795);
INSERT INTO TrojanMap(name, long, lat) VALUES ('5 VKC', -118.2840025610536, 34.021416240746255);
INSERT INTO TrojanMap(name, long, lat) VALUES ('6 Roski Schoold of Fine Arts',-118.2871674605398, 34.019614107060804 );
INSERT INTO TrojanMap(name, long, lat) VALUES ('7 Marshall Business School', -118.28548119518732, 34.0190636256359);
INSERT INTO TrojanMap(name, long, lat) VALUES ('8 Admission Center', -118.2859683996235, 34.020207774967695);
INSERT INTO TrojanMap(name, long, lat) VALUES ('9 International Academy',-118.28058885064071, 34.022024921619234 );
INSERT INTO TrojanMap(name, long, lat) VALUES ('10 School of Cinematic Arts', -118.28649826157883, 34.02378965033796);
INSERT INTO TrojanMap(name, long, lat) VALUES ('11 Keck Medicine of USC', -118.28876297985045, 34.02535735597369);
INSERT INTO TrojanMap(name, long, lat) VALUES ('12 Taper Hall', -118.28457380154424, 34.022273424229965);
INSERT INTO TrojanMap(name, long, lat) VALUES ('13 CityPark APT', -118.29046797382453, 34.027942856245474);

/* Create a geometry type column */
ALTER TABLE TrojanMap ADD COLUMN geom geometry(POINT, 4326);

/* Derive geometry values (in WGS84/SRID4326 format) from lat, lng values */
UPDATE TrojanMap SET geom = ST_SetSRID(ST_MakePoint(lat, long), 4326);


/*Find Convex Hull Coordinates*/
SELECT ST_AsText(ST_ConvexHull(ST_Collect(geom))) FROM TrojanMap;
/*result:
POLYGON((34.027942856245474 -118.29046797382453,34.02081408624823 -118.28926141247756,34.019614107060804 -118.2871674605398,34.0190636256359 -118.28548119518732,34.022024921619234 -118.28058885064071,34.027942856245474 -118.29046797382453))
(1 row)
*/

/* Find 4 Nearest Neighbors */
SELECT t2.name as Building, ST_DISTANCE(t1.geom, t2.geom) as distance FROM TrojanMap t1 JOIN TrojanMap t2 on t1.id != t2.id WHERE t1.name = '13 CityPark APT' ORDER BY distance LIMIT 4;
/*
result:
 building                       |       distance        
-----------------------------------------------------+-----------------------
 11 Keck Medicine of USC                             |  0.003097065725339471
 10 School of Cinematic Arts                         |  0.005745235819695537
 2 Annenberg School for Communication and Journalism |  0.007142222456104605
 1 Viterbi School of Engineering                     | 0.0072301557353648006
(4 rows)

