CSCI 585 HW3
NAME: Haoyu Wu
USC ID: 8817850595


Q6 URL:
http://jsfiddle.net/gjbs3qaz/
