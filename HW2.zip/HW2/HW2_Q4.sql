BEGIN 
EXECUTE IMMEDIATE 'DROP TABLE Jan_Expenditure';
EXECUTE IMMEDIATE 'DROP TABLE Supply';
EXCEPTION
WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE Jan_Expenditure(
Expenditure_Type VARCHAR2(30) NOT NULL,
Amount NUMBER(10,2) NOT NULL
);
CREATE TABLE Supply
(
Supply_ID INTEGER PRIMARY KEY NOT NULL,
Supply_Name VARCHAR2(50),
Supply_Cost NUMBER(10,2) NOT NULL,
Purchase_Date DATE NOT NULL
);
INSERT INTO Supply (Supply_ID,Supply_Name,Supply_Cost,Purchase_Date) VALUES (100,'Medical alcohol',500.00 ,TO_DATE('2021-01-02','yyyy-mm-dd'));
INSERT INTO Supply (Supply_ID,Supply_Name,Supply_Cost,Purchase_Date) VALUES (101,'Scalpel',1800.00,TO_DATE('2021-01-12','yyyy-mm-dd'));
INSERT INTO Supply (Supply_ID,Supply_Name,Supply_Cost,Purchase_Date) VALUES (102,'Tweezer',269.00 ,TO_DATE('2021-01-13','yyyy-mm-dd'));
INSERT INTO Supply (Supply_ID,Supply_Name,Supply_Cost,Purchase_Date) VALUES (103,'Face Mask',785.20,TO_DATE('2021-01-15','yyyy-mm-dd'));
INSERT INTO Supply (Supply_ID,Supply_Name,Supply_Cost,Purchase_Date) VALUES (104,'Ultra Violet Light',1200.00,TO_DATE('2021-01-21','yyyy-mm-dd'));

INSERT INTO Jan_Expenditure(Expenditure_Type, Amount) VALUES ('Lease', 29000.00);
INSERT INTO Jan_Expenditure(Expenditure_Type, Amount) VALUES ('Total Employee Salaries', 135890.00);
INSERT INTO Jan_Expenditure(Expenditure_Type, Amount) VALUES ('Advertisement', 35000.00);
INSERT INTO Jan_Expenditure(Expenditure_Type,Amount) VALUES('Supply', 0);

UPDATE Jan_Expenditure SET Amount = (SELECT SUM(Supply_Cost) FROM Supply
WHERE Purchase_Date<=TO_DATE('2021-01-31','yyyy-mm-dd') AND Purchase_Date>=TO_DATE('2021-01-01','yyyy-mm-dd'))
WHERE Expenditure_Type = 'Supply';

Select * from Jan_Expenditure;

DROP TABLE Jan_Expenditure;
DROP TABLE Supply;
  
  