BEGIN 
EXECUTE IMMEDIATE 'DROP TABLE Medical_Procedure';
EXECUTE IMMEDIATE 'DROP TABLE Cumulative_Income';
EXCEPTION
WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE Cumulative_Income(
Income_Date DATE NOT NULL,
Amount NUMBER(10,2) NOT NULL,
Cumulative_Amount NUMBER(10,2) 
);
CREATE TABLE Medical_Procedure
(
Procedure_ID INTEGER NOT NULL,
Patient_ID INTEGER NOT NULL,
Procedure_Date DATE NOT NULL,
Start_Time DATE NOT NULL,
End_Time DATE NOT NULL,
Procedure_Income NUMBER(10,2) NOT NULL
);

INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (1,3,to_date('2021-01-01','yyyy-mm-dd'), to_date('09:35:00','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'), 500.35);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (2,5,to_date('2021-01-01','yyyy-mm-dd'),to_date('12:23:10','hh24:mi:ss'), to_date('15:25:19','hh24:mi:ss'), 325.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (3,8,to_date('2021-01-03','yyyy-mm-dd'),to_date('11:25:04','hh24:mi:ss'), to_date('13:15:20','hh24:mi:ss'), 1800.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (2,10,to_date('2021-01-04','yyyy-mm-dd'),to_date('10:12:09','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'), 450.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (3,11,to_date('2021-01-07','yyyy-mm-dd'),to_date('12:24:10','hh24:mi:ss'), to_date('15:25:12','hh24:mi:ss'), 600.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (5,13,to_date('2021-01-10','yyyy-mm-dd'),to_date('15:35:10','hh24:mi:ss'), to_date('17:38:20','hh24:mi:ss'), 800.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (3,29,to_date('2021-01-12','yyyy-mm-dd'),to_date('14:12:23','hh24:mi:ss'), to_date('16:34:30','hh24:mi:ss'), 880.20);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (4,90,to_date('2021-01-12','yyyy-mm-dd'),to_date('13:32:56','hh24:mi:ss'), to_date('15:56:26','hh24:mi:ss'), 980.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (5,30,to_date('2021-01-15','yyyy-mm-dd'),to_date('17:38:46','hh24:mi:ss'), to_date('18:45:54','hh24:mi:ss'), 820.16);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (2,11,to_date('2021-01-19','yyyy-mm-dd'),to_date('16:45:49','hh24:mi:ss'), to_date('19:25:48','hh24:mi:ss'), 545.78);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (1,3,to_date('2021-01-21','yyyy-mm-dd'),to_date('09:35:00','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'), 500.35);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (2,5,to_date('2021-02-01','yyyy-mm-dd'),to_date('12:23:10','hh24:mi:ss'), to_date('15:25:19','hh24:mi:ss'), 320.50);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (4,8,to_date('2021-02-03','yyyy-mm-dd'),to_date('11:25:04','hh24:mi:ss'), to_date('13:15:20','hh24:mi:ss'), 180.65);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (2,10,to_date('2021-02-04','yyyy-mm-dd'),to_date('10:12:09','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'),785.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (3,16,to_date('2021-02-12','yyyy-mm-dd'),to_date('12:42:53','hh24:mi:ss'), to_date('15:12:30','hh24:mi:ss'),1274.60);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Income) VALUES (4,15,to_date('2021-03-02','yyyy-mm-dd'),to_date('12:42:53','hh24:mi:ss'), to_date('15:12:30','hh24:mi:ss'),1274.60);

SELECT SUM(Procedure_Income) AS DAILY_INCOME FROM Medical_Procedure
WHERE Procedure_Date = TO_DATE(SYSDATE);

INSERT INTO Cumulative_Income (Income_Date, Amount) 
SELECT Procedure_Date, SUM(Procedure_Income) from Medical_Procedure 
GROUP BY Procedure_Date;

SELECT Income_Date, Amount, SUM(Amount) OVER (ORDER BY Income_Date) Cumulative_Amount FROM Cumulative_Income;

DROP TABLE Medical_Procedure;
DROP TABLE Cumulative_Income;
