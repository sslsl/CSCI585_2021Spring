Q1:
https://livesql.oracle.com/apex/livesql/s/lgbgh6ha1tnrpuq66ch8tfo81

Assumption:
I created a Medical_Procedure table, we can use "Procedure_Cost" to get the average cost of different procedures
"Procedure_Date","Start_time", "End_time" can be used to get average time in minutes of different procedures
------------------------------------------------------------
------------------------------------------------------------
Q2:
https://livesql.oracle.com/apex/livesql/s/lge5v4a84qtyaem0qxir7vqrm

Assumption:
First, I created a Medical_Procedure table, we can use "Procedure_Income" to get the DAILY_INCOME. 
In this question, I used 02-Mar-2021 as the day that need to be calculated. 
Then, I created a Cumulative_Income table. This table can record cumulative income. 
After we selected the DAILY_INCOME, this record can be added into Cumulative_Income with the date. 
Finally, I selected the Cumulative_Income to display the cumulative income of each day.
------------------------------------------------------------
------------------------------------------------------------
Q3:
https://livesql.oracle.com/apex/livesql/s/lge6vdsa7ptw4ld22cev0ra9a

Assumption:
First, I created two tables, "Task" table to record the skills that the owners want. "Capabilities" table to record employee's skill.
Then, I selected the employee id that can do all "Task_Type" listed in "Task" table, and display the result of employee id. 

------------------------------------------------------------
------------------------------------------------------------
Q4:
https://livesql.oracle.com/apex/livesql/s/lgfi7wcsot4wqh55tqifc5t9a
Assumption:
In this question, the owner can find the total cost of supply purchases in a certain month(January in my example). Then the result can be added to January Expenditure Table. 
This can display different types of January Expenditure. The owner would like to see the expenditure cost of each type, including all supply purchases in January. 

Query:
UPDATE Jan_Expenditure SET Amount = (SELECT SUM(Supply_Cost) FROM Supply
WHERE Purchase_Date<=TO_DATE('2021-01-31','yyyy-mm-dd') AND Purchase_Date>=TO_DATE('2021-01-01','yyyy-mm-dd'))
WHERE Expenditure_Type = 'Supply';
Select * from Jan_Expenditure;

Entities description:
1. Jan_Expenditure
This entity is used to display the January Expenditure of this clinic.
Tis entity contains two attributes: 
Expenditure_Type VARCHAR2(30) NOT NULL, 
Amount NUMBER(10,2) NOT NULL
Expenditure_Type is different types of expenditure such as monthly lease, supply, salary.
Amount is the cost of each expenditure type;

2. Supply
This entity is used to record all purchase of supplies. 
This entity contains4 attributes: 
Supply_ID INTEGER PRIMARY KEY NOT NULL,
Supply_Name VARCHAR2(50),
Supply_Cost NUMBER(10,2) NOT NULL,
Purchase_Date DATE NOT NULL
