BEGIN 
EXECUTE IMMEDIATE 'DROP TABLE Medical_Procedure';
EXCEPTION
WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE Medical_Procedure
(
Procedure_ID INTEGER NOT NULL,
Patient_ID INTEGER NOT NULL,
Procedure_Date Date NOT NULL,
Start_Time DATE NOT NULL,
End_Time DATE NOT NULL,
Procedure_Cost NUMBER(10,2) NOT NULL
);

INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (1,3,to_date('2021-01-01','yyyy-mm-dd'), to_date('09:35:00','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'), 50.35);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (2,5,to_date('2021-01-01','yyyy-mm-dd'),to_date('12:23:10','hh24:mi:ss'), to_date('14:25:19','hh24:mi:ss'), 126.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (3,8,to_date('2021-01-03','yyyy-mm-dd'),to_date('11:25:04','hh24:mi:ss'), to_date('12:50:20','hh24:mi:ss'), 180.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (2,10,to_date('2021-01-04','yyyy-mm-dd'),to_date('10:12:05','hh24:mi:ss'), to_date('12:12:20','hh24:mi:ss'), 45.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (3,11,to_date('2021-01-07','yyyy-mm-dd'),to_date('12:24:10','hh24:mi:ss'), to_date('15:22:12','hh24:mi:ss'), 65.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (5,13,to_date('2021-01-10','yyyy-mm-dd'),to_date('15:35:00','hh24:mi:ss'), to_date('17:38:20','hh24:mi:ss'), 80.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (3,29,to_date('2021-01-12','yyyy-mm-dd'),to_date('14:12:24','hh24:mi:ss'), to_date('15:31:30','hh24:mi:ss'), 92.20);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (4,90,to_date('2021-01-12','yyyy-mm-dd'),to_date('13:32:56','hh24:mi:ss'), to_date('15:56:26','hh24:mi:ss'), 98.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (5,30,to_date('2021-01-15','yyyy-mm-dd'),to_date('17:38:46','hh24:mi:ss'), to_date('18:45:54','hh24:mi:ss'), 82.16);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (2,11,to_date('2021-01-19','yyyy-mm-dd'),to_date('16:45:49','hh24:mi:ss'), to_date('19:25:48','hh24:mi:ss'), 54.78);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (1,3,to_date('2021-01-21','yyyy-mm-dd'),to_date('09:35:00','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'), 50.35);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (2,5,to_date('2021-02-01','yyyy-mm-dd'),to_date('12:23:10','hh24:mi:ss'), to_date('15:25:19','hh24:mi:ss'), 120.50);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (4,8,to_date('2021-02-03','yyyy-mm-dd'),to_date('11:25:04','hh24:mi:ss'), to_date('13:15:20','hh24:mi:ss'), 180.65);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (2,10,to_date('2021-02-04','yyyy-mm-dd'),to_date('10:12:09','hh24:mi:ss'), to_date('10:55:20','hh24:mi:ss'),78.00);
INSERT INTO Medical_Procedure (Procedure_ID, Patient_ID, Procedure_Date, Start_Time, End_Time, Procedure_Cost) VALUES (3,16,to_date('2021-02-12','yyyy-mm-dd'),to_date('12:42:53','hh24:mi:ss'), to_date('15:12:30','hh24:mi:ss'),174.60);

-- Q1
SELECT mp.Procedure_ID , AVG(mp.Procedure_Cost) AS AVG_COST, 
AVG(ROUND(TO_NUMBER(mp.End_Time-mp.Start_Time)*24*60)) AS "AVG_TIME(minitues)"
FROM Medical_Procedure mp
WHERE mp.Procedure_Date<=to_date('2021-01-31','yyyy-mm-dd') AND mp.Procedure_Date>=to_date('2021-01-01','yyyy-mm-dd')
GROUP BY mp.Procedure_ID 
ORDER BY mp.Procedure_ID ASC;

DROP TABLE Medical_Procedure