BEGIN 
EXECUTE IMMEDIATE 'DROP TABLE Task';
EXECUTE IMMEDIATE 'DROP TABLE Capabilities';
EXCEPTION
WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE Task(
Task_Type VARCHAR2(30) NOT NULL
);
CREATE TABLE Capabilities
(
EMPLOYEE_ID INTEGER NOT NULL,
SKILL VARCHAR2(50) NOT NULL
);
INSERT INTO Task (Task_Type) VALUES ('File taxes');
INSERT INTO Task (Task_Type) VALUES ('Meet the press');
INSERT INTO Task (Task_Type) VALUES ('Organize spring cleaning');
INSERT INTO Task (Task_Type) VALUES ('Do teeth cleaning');
INSERT INTO Task (Task_Type) VALUES ('Reorder inventory');

INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (1,'File taxes');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (1,'Meet the press');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (1,'Organize spring cleaning');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (1,'Do teeth cleaning');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (1,'Reorder inventory');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (2,'Dance');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (3,'Meet the press');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (5,'Do teeth cleaning');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (6,'Meet the press');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (8,'File taxes');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (8,'Meet the press');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (8,'Organize spring cleaning');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (8,'Do teeth cleaning');
INSERT INTO Capabilities(EMPLOYEE_ID, SKILL) VALUES (8,'Reorder inventory');

SELECT c.EMPLOYEE_ID FROM Capabilities c 
WHERE c.SKILL IN (SELECT Task_Type FROM Task) 
GROUP BY c.EMPLOYEE_ID
HAVING COUNT(*) = (SELECT COUNT(*) FROM Task);

DROP TABLE Task;
DROP TABLE Capabilities;